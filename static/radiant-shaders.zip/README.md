# Radiant — Open Source Shaders & Effects

A collection of 88 standalone, self-contained shaders & effects for the web.

## Usage

Each HTML file is a fully self-contained animation — no build step, no dependencies.
Simply open any file in a modern browser, or embed it in your project via an iframe:

```html
<iframe src="flow-field.html" width="800" height="600"></iframe>
```

You can also copy the code into your own HTML pages and customize it directly.

## Included Shaders

01. 플로우 필드 with 파티클 트레일 — flow-field.html
02. 지형 등고선 지도 — topographic.html
03. 생성형 가지 나무 — generative-tree.html
04. 이상 어트랙터 (로렌츠) — strange-attractor.html
05. 진자 파동 — pendulum-wave.html
06. 엽상체 나선 — phyllotaxis.html
07. 앰버 플루이드 — fluid-amber.html
08. 샴페인 거품 — champagne-fizz.html
09. 슈거 글라스 — sugar-glass.html
10. 공명하는 현 — resonant-strings.html
11. 클라드니 공명 — chladni-resonance.html
12. 키네틱 그리드 — kinetic-grid.html
13. 스트로브 기하 — strobe-geometry.html
14. 레이저 미로 — laser-labyrinth.html
15. 베이스 잔물결 — bass-ripple.html
16. 잉크 용해 — ink-dissolve.html
17. 스팽글 파동 — sequin-wave.html
18. 금박 모자이크 — gilt-mosaic.html
19. 금빛 균열 — gilded-fracture.html
20. 빛나는 기하 — radiant-geometry.html
21. 황금 왕좌 — golden-throne.html
22. 신성한 기이함 — sacred-strange.html
23. 열대의 열기 — tropical-heat.html
24. 네온 방울 — neon-drip.html
25. 전압 아크 — voltage-arc.html
26. 달빛 잔물결 — moonlit-ripple.html
27. 일식의 빛 — eclipse-glow.html
28. 다이아몬드 카우스틱 — diamond-caustics.html
29. 유리창의 빗방울 — rain-on-glass.html
30. 우산 위의 비 — rain-umbrella.html
31. 변태 — metamorphosis.html
32. 아트팝 무지개빛 — artpop-iridescence.html
33. 실크 그루브 — silk-groove.html
34. 금빛 실 — gilt-thread.html
35. 사건의 지평선 — event-horizon.html
36. 타오르는 필름 — burning-film.html
37. 현기증 — vertigo.html
38. 별가루 장막 — stardust-veil.html
39. 실크 폭포 — silk-cascade.html
40. 잔불 — smolder.html
41. 신호 감쇠 — signal-decay.html
42. 네온 리바이벌 — neon-revival.html
43. 번진 립스틱 — lipstick-smear.html
44. 글리터 폭풍 — glitter-storm.html
45. 고무 같은 현실 — rubber-reality.html
46. 마그마 핵 — magma-core.html
47. 태엽장치의 정신 — clockwork-mind.html
48. 혼돈의 가장자리 — edge-of-chaos.html
49. 스파크 챔버 — spark-chamber.html
50. 흔들리는 장막 — shifting-veils.html
51. 결정 격자 — crystal-lattice.html
52. 만화경 런웨이 — kaleidoscope-runway.html
53. 디지털 비 — digital-rain.html
54. 네온 드라이브 — neon-drive.html
55. 액체 금 — liquid-gold.html
56. 오로라 장막 — aurora-veil.html
57. 생물 발광 — bioluminescence.html
58. 고딕 세공 — gothic-filigree.html
59. 레이저 정밀도 — laser-precision.html
60. 자기 모래 — magnetic-sand.html
61. 직조된 광채 — woven-radiance.html
62. 재즈 카오스 — jazz-chaos.html
63. 천둥의 설교 — thunder-sermon.html
64. 바이닐 홈 — vinyl-grooves.html
65. 빈티지 노이즈 — vintage-static.html
66. 찢긴 종이 — torn-paper.html
67. 폴라로이드 번인 — polaroid-burn.html
68. 비명의 파동 — scream-wave.html
69. 잉크 캘리그래피 — ink-calligraphy.html
70. 벨벳 스포트라이트 — velvet-spotlight.html
71. 새 떼의 군무 — murmuration.html
72. 테서랙트의 그림자 — tesseract-shadow.html
73. 모아레 간섭 — moire-interference.html
74. 상전이 — phase-transition.html
75. 자기장 — magnetic-field.html
76. 오로라 커튼 — aurora-curtain.html
77. 소용돌이 — vortex.html
78. 색채의 개화 — chromatic-bloom.html
79. 렌즈의 속삭임 — lens-whisper.html
80. 빛나는 실트 — luminous-silt.html
81. 신스 리본 — synth-ribbon.html
82. 홀로그램 글리치 — hologram-glitch.html
83. 부서진 평원 — shattered-plains.html
84. 채색된 지층 — painted-strata.html
85. 피드백 루프 — feedback-loop.html
86. 디더 그라디언트 — dither-gradient.html
87. 아날로그 드리프트 — analog-drift.html
88. 새해 폭죽 — new-year-fireworks.html

## License

These shaders are free and open source under the MIT License. See LICENSE for full terms.
Use them however you like — personal projects, commercial products, client work.

If you find them useful, consider supporting the project at https://radiantshaders.com
